
rootProject.name = "lojadevarejo2"

